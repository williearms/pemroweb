<!DOCTYPE html>
<html>
<head>
		<title>CRUD PHP</title>
  <link rel="stylesheet" type="text/css" href="dist/components/reset.css">
  <link rel="stylesheet" type="text/css" href="dist/components/site.css">
  <link rel="stylesheet" type="text/css" href="dist/components/grid.css">

  <!--- Component CSS -->
  <link rel="stylesheet" type="text/css" href="dist/components/icon.css">
  <link rel="stylesheet" type="text/css" href="dist/components/table.css">
  <link rel="stylesheet" type="text/css" href="dist/components/button.css">
  <link rel="stylesheet" type="text/css" href="dist/components/transition.css">
  <link rel="stylesheet" type="text/css" href="dist/components/popup.css">

  <!--- Component JS -->
		
		<style>
		  body {
 			   padding: 1em;
 			   background-color: #DADADA;
				}
		  .ui.table {
 			   table-layout: fixed;
  					}
			a.ple{
				margin:center;
				font-family:calibri;
				font-size:300%;
			}

		</style>
</head>
<body>
<div class="ui middle aligned left aligned grid">
  <div class="column">
    <h2 class="ui teal image header">
      <div class="content">
        Data Berita
        <a href="index.php" style="margin-left:1000px" class="green ui button">Back to Create</a>
      </div>
    </h2>
<div class="column">
<table class="ui padded celled center aligned table">
<tr>
		<th>No</th>
		<th>Judul Berita</th>
		<th>Headline Berita</th>
		<th>Isi Berita</th>
		<th>Author</th>
		<th>Tanggal Post</th>
		<th colspan="2">Aksi</th>
</tr>
		<?php
				require 'koneksi.php';
				$no = 1;
				$query = mysql_query("SELECT * FROM berita");
				while ($hasil = mysql_fetch_array($query)) { ?>
				<tr>
				<td><?php echo $no++; ?></td>
				<td><?php echo $hasil[1]?></td>
				<td><?php echo $hasil[2]?></td>
				<td><?php echo $hasil[3]?></td>
				<td><?php echo $hasil[4]?></td>
				<td><?php echo $hasil[5]?></td>
				<td>
				<a class="ui primary button" href="update.php?berita_id=<?php echo $hasil[0]?>">Update
				</td>
				<td>
				<a class="ui secondary button" href="delete.php?berita_id=<?php echo $hasil[0]?>">Delete
				</td>
				</tr>
<?php }?>
		</table>
</div>
		<br>
		<br>
		<a class=ple href="index.php"> Kembali ke Create </a>
</div>
</div>
</body>
</html>